from flask import Blueprint, jsonify, request, session
from src.models.user import User, Credit, Product, db

credits_bp = Blueprint('credits', __name__)

def require_auth():
    """Helper function to check authentication"""
    if 'user_id' not in session:
        return None
    return User.query.get(session['user_id'])


@credits_bp.route('/credits/balance', methods=['GET'])
def get_credit_balance():
    """Get current user's credit balance"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    if not user.credits:
        # Create credit record if doesn't exist
        credit = Credit(user_id=user.id, balance=0)
        db.session.add(credit)
        db.session.commit()
        return jsonify({'balance': 0}), 200
    
    return jsonify({'balance': user.credits.balance}), 200


@credits_bp.route('/credits/add', methods=['POST'])
def add_credits():
    """Add credits to user account (for product purchases)"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        if not data or 'amount' not in data:
            return jsonify({'error': 'Amount is required'}), 400
        
        amount = int(data['amount'])
        if amount <= 0:
            return jsonify({'error': 'Amount must be positive'}), 400
        
        # Get or create credit record
        if not user.credits:
            credit = Credit(user_id=user.id, balance=amount)
            db.session.add(credit)
        else:
            user.credits.balance += amount
        
        db.session.commit()
        
        return jsonify({
            'message': f'{amount} credits added successfully',
            'new_balance': user.credits.balance if user.credits else amount
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@credits_bp.route('/credits/deduct', methods=['POST'])
def deduct_credits():
    """Deduct credits from user account (for chat messages)"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        if not data or 'amount' not in data:
            return jsonify({'error': 'Amount is required'}), 400
        
        amount = int(data['amount'])
        if amount <= 0:
            return jsonify({'error': 'Amount must be positive'}), 400
        
        # Check if user has credits
        if not user.credits or user.credits.balance < amount:
            return jsonify({'error': 'Insufficient credits'}), 400
        
        # Deduct credits
        user.credits.balance -= amount
        db.session.commit()
        
        return jsonify({
            'message': f'{amount} credits deducted successfully',
            'new_balance': user.credits.balance
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@credits_bp.route('/credits/purchase', methods=['POST'])
def purchase_product():
    """Simulate product purchase and add credits"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        if not data or 'product_id' not in data:
            return jsonify({'error': 'Product ID is required'}), 400
        
        product = Product.query.get(data['product_id'])
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Add credits for the product
        if not user.credits:
            credit = Credit(user_id=user.id, balance=product.credits_awarded)
            db.session.add(credit)
        else:
            user.credits.balance += product.credits_awarded
        
        db.session.commit()
        
        return jsonify({
            'message': f'Product "{product.name}" purchased successfully',
            'credits_awarded': product.credits_awarded,
            'new_balance': user.credits.balance if user.credits else product.credits_awarded
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@credits_bp.route('/products', methods=['GET'])
def get_products():
    """Get all available products"""
    products = Product.query.all()
    return jsonify([product.to_dict() for product in products]), 200


@credits_bp.route('/products', methods=['POST'])
def create_product():
    """Create a new product (admin function)"""
    try:
        data = request.json
        if not data or not all(k in data for k in ['name', 'price', 'credits_awarded']):
            return jsonify({'error': 'Name, price, and credits_awarded are required'}), 400
        
        product = Product(
            name=data['name'],
            description=data.get('description', ''),
            price=float(data['price']),
            credits_awarded=int(data['credits_awarded'])
        )
        
        db.session.add(product)
        db.session.commit()
        
        return jsonify({
            'message': 'Product created successfully',
            'product': product.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

