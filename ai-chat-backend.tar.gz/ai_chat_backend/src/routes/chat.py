from flask import Blueprint, jsonify, request, session
from src.models.user import User, ChatLog, db
import requests
import os

chat_bp = Blueprint('chat', __name__)

def require_auth():
    """Helper function to check authentication"""
    if 'user_id' not in session:
        return None
    return User.query.get(session['user_id'])


@chat_bp.route('/chat/send', methods=['POST'])
def send_message():
    """Send a message to AI and get response"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400
        
        user_message = data['message'].strip()
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Check if user has enough credits (assuming 1 credit per message for now)
        credits_per_message = 1
        if not user.credits or user.credits.balance < credits_per_message:
            return jsonify({'error': 'Insufficient credits. Please purchase a product to continue.'}), 400
        
        # Save user message to chat log
        user_chat_log = ChatLog(
            user_id=user.id,
            message_text=user_message,
            is_user_message=True,
            credits_deducted=0
        )
        db.session.add(user_chat_log)
        
        # Get AI response
        ai_response = get_ai_response(user_message)
        
        # Deduct credits
        user.credits.balance -= credits_per_message
        
        # Save AI response to chat log
        ai_chat_log = ChatLog(
            user_id=user.id,
            message_text=ai_response,
            is_user_message=False,
            credits_deducted=credits_per_message
        )
        db.session.add(ai_chat_log)
        
        db.session.commit()
        
        return jsonify({
            'user_message': user_message,
            'ai_response': ai_response,
            'credits_deducted': credits_per_message,
            'remaining_credits': user.credits.balance
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


@chat_bp.route('/chat/history', methods=['GET'])
def get_chat_history():
    """Get user's chat history"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Get chat logs for the user
        chat_logs = ChatLog.query.filter_by(user_id=user.id)\
                                .order_by(ChatLog.timestamp.desc())\
                                .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'chat_history': [log.to_dict() for log in chat_logs.items],
            'total': chat_logs.total,
            'pages': chat_logs.pages,
            'current_page': page,
            'per_page': per_page
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@chat_bp.route('/chat/clear', methods=['DELETE'])
def clear_chat_history():
    """Clear user's chat history"""
    user = require_auth()
    if not user:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        # Delete all chat logs for the user
        ChatLog.query.filter_by(user_id=user.id).delete()
        db.session.commit()
        
        return jsonify({'message': 'Chat history cleared successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500


def get_ai_response(message):
    """
    Get AI response from OpenAI API or alternative AI service
    """
    # Check for OpenAI API key
    openai_api_key = os.getenv('OPENAI_API_KEY')
    
    if openai_api_key:
        try:
            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers={
                    'Authorization': f'Bearer {openai_api_key}',
                    'Content-Type': 'application/json'
                },
                json={
                    'model': 'gpt-3.5-turbo',
                    'messages': [
                        {
                            'role': 'system', 
                            'content': 'You are a helpful AI assistant. Respond in Arabic if the user writes in Arabic, otherwise respond in English.'
                        },
                        {
                            'role': 'user', 
                            'content': message
                        }
                    ],
                    'max_tokens': 150,
                    'temperature': 0.7
                },
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()['choices'][0]['message']['content']
            else:
                return "عذراً، أواجه مشكلة في معالجة طلبك الآن. يرجى المحاولة مرة أخرى لاحقاً."
                
        except Exception as e:
            return "عذراً، أواجه مشكلة في معالجة طلبك الآن. يرجى المحاولة مرة أخرى لاحقاً."
    
    else:
        # Fallback to a simple AI-like response when no API key is available
        responses = {
            'hello': 'مرحباً! كيف يمكنني مساعدتك اليوم؟',
            'hi': 'أهلاً وسهلاً! أنا هنا لمساعدتك.',
            'how are you': 'أنا بخير، شكراً لسؤالك! كيف يمكنني مساعدتك؟',
            'what is your name': 'أنا مساعد ذكي مصمم لمساعدتك. ما اسمك؟',
            'help': 'بالطبع! أخبرني كيف يمكنني مساعدتك.',
            'مرحبا': 'أهلاً وسهلاً! كيف يمكنني مساعدتك؟',
            'السلام عليكم': 'وعليكم السلام ورحمة الله وبركاته! أهلاً بك.',
            'كيف حالك': 'الحمد لله، أنا بخير. كيف يمكنني مساعدتك اليوم؟',
            'ما اسمك': 'أنا مساعد ذكي مصمم لمساعدتك في موقع mutayer.com',
            'مساعدة': 'بالطبع! أخبرني ما تحتاج إليه وسأكون سعيداً لمساعدتك.'
        }
        
        message_lower = message.lower().strip()
        
        # Check for exact matches first
        for key, response in responses.items():
            if key in message_lower:
                return response
        
        # Default response
        if any(char in message for char in 'أبتثجحخدذرزسشصضطظعغفقكلمنهوي'):
            return f'شكراً لرسالتك "{message}". أنا مساعد ذكي وأحاول فهم ما تحتاج إليه. يمكنك سؤالي عن أي شيء!'
        else:
            return f'Thank you for your message "{message}". I\'m an AI assistant and I\'m trying to understand what you need. Feel free to ask me anything!'

